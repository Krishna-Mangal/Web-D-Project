const mongoose = require("mongoose");
const initData = require("./data.js");
const Listing = require("../models/listing.js");
 
main().then(res =>{
    console.log("connection successfull");
}).catch(err =>{
    console.log(err);
})

async function main() {
    await mongoose.connect("mongodb+srv://krush884:54cvar8mtf@krushcluster.hmxy5.mongodb.net/majorProject");
}

const initDB = async () => {
    await Listing.deleteMany({});
    await Listing.insertMany(initData.data);
    console.log("data inserted");
};

initDB();