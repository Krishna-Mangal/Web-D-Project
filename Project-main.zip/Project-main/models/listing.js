const mongoose = require("mongoose");

const list = new mongoose.Schema({
   title : {
    type : String,
    required : true
   },
   description :{
    type: String,
   },
   image: {
      filename: String,
      url: {
         type:String,
         set: (v) => v === "" ? "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.7cRYFyLoDEDh4sRtM73vvwHaDg%26pid%3DApi&f=1&ipt=a6db7517dae05899f6a4411f599c488be08e56d734618d92b1d0454cee5353a2&ipo=images": v,
      }
   },
   price :{
    type :Number,
   },
   location :{
    type:String,
   },
   country :{
    type:String
   },
   reviews:[{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Review",
   }]
});

const Listing = mongoose.model("Listing", list);

module.exports = Listing;